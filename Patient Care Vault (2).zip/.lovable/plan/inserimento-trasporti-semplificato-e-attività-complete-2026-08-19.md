# Inserimento trasporti semplificato e attività complete

## Obiettivo
Ridurre al minimo digitazione e conferme senza alterare trasporti esistenti o PDF ASUFC, aggiungendo una coda di revisione e un registro attività davvero trasversale.

## Trasporti secondari
- Ridisegnare il blocco tratta in base al tipo:
  - **ADI / altri:** viaggi frequenti come selettore immediato e ricercabile; un clic compila partenza, destinazione/alias e collega internamente la tratta. Il collegamento sostituisce il messaggio “tratta registrata”.
  - **Interospedalieri:** due campi chiari con ricerca rapida, testo libero sempre ammesso, inversione immediata e riconoscimento automatico della coppia tariffaria.
- Conservare la regola fondamentale: la selezione può compilare i valori della tratta quando il campo è vuoto, ma non sovrascrive mai km/prezzo già digitati, incluso `0`.
- Mostrare un feedback discreto di collegamento riuscito, senza passaggi di conferma aggiuntivi e senza il pulsante “Applica” per una tratta riconosciuta.
- Salvare un riferimento opzionale alla tratta ADI collegata, così modifica e rilettura restano precise anche se i testi cambiano.
- Aggiungere **Da revisionare** al modulo di inserimento/modifica e un filtro rapido nell’elenco, con indicatore visivo e comando per chiudere la revisione.
- Mantenere invariati dati storici, campi richiesti ed esportazione PDF ASUFC.

## Centro sicurezza e attività
- Estendere il registro automatico a tutte le principali aree operative del sito, inclusi trasporti, servizi sportivi, checklist, questionari, notifiche, impostazioni, aree e configurazioni.
- Rifare “Registro attività” come vista principale pulita con:
  - riepilogo attività recenti;
  - ricerca per operatore/testo;
  - filtri per area, azione e periodo;
  - righe leggibili in italiano con data, operatore, azione, sezione e dettaglio essenziale;
  - dettaglio espandibile solo quando serve.
- Non esporre nel registro dati clinici o contenuti sensibili completi: mostrare metadati operativi sintetici, lasciando i dettagli tecnici protetti.
- Tenere separati e accessibili gli strumenti di sicurezza esistenti (sessioni, blocchi, visibilità schede).

## Database e compatibilità
- Migrazione additiva su `secondary_transports`: flag revisione, data/utente revisione e riferimento opzionale alla tratta ADI; nessuna modifica distruttiva.
- Aggiungere trigger di audit alle tabelle operative mancanti, riutilizzando il registro protetto esistente.
- Aggiornare i tipi e le query interessate; nessuna modifica ai record esistenti e nessun cambiamento al formato PDF.

## Verifica
- Testare inserimento e modifica per ADI normale, ADI alias, A/R, interospedaliero registrato e destinazione libera.
- Verificare che `0` e valori manuali non vengano sovrascritti.
- Verificare apertura/chiusura revisione, filtri elenco e persistenza.
- Verificare registro attività su più sezioni, filtri desktop/mobile e assenza di dati sensibili nei riepiloghi.
- Controllare build, errori runtime e flussi principali nel browser.
